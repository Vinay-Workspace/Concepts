public interface Myinterface {

    public void getdata();

    public void getname();

    public void getdpic();

    public void getemail();
}
