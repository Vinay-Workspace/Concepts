public class WhileandDoWhileLoop {
    public static void main(String[] args) {
        // System.out.println("Hello, World!");

        int i = 0;
        while (i < 5) {
            System.out.println("values are " + i);
            i++;
        }

        int j = 20;
        do {
            System.out.println("number increamenting by ::" + j++);
        } while (j < 30);
        {
            // !Character.isDigit(System.in.read())
            System.out.println(j);
        }
    }
}
