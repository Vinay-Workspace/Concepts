public class Super_keyword_parentclass {
    String name = "Karmen Lincoln";

    public static void main(String[] args) {

    }

}
