public interface interface2 {

    public void greeting();

}
