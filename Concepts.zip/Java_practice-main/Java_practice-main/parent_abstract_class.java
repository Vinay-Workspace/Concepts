public abstract class parent_abstract_class {

    public void quotes() {
        System.out.println("If you change nothing Nothing will change");
    }

    public void Hope() {

        System.out.println("Hope for the best");
        System.out.println("Hope is the thing with feathers - that perches in ");
    }

    public abstract void Dream();

}
